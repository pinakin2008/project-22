# ABOUT THE PROJECT
This contains the files that were edited and coded in the Project 22 in WhitehatJR Pro Course. It has a fairy sprite that can move and also a star sprite that can fall on clicking down arrow. It is coded in javascript using "matter.js". To change the logic, edit the code in the file 'sketch.js' file.

# ABOUT ME

![My Image](swastik.png)

- 👋 Hi, I’m [Swastik Bhattacharjee](https://github.com/Swastik-WhitehatJR).
- 👀 I’m interested in Programming and designing.
- 🌱 I’m currently learning Web Development.
- 💞️ I’m now learning to it on WhitehatJR.
- 📫 You can reach me by mentioning me in github at @Swastik-WhitehatJR.
- 💌 You can to mail me in swastikbhattacharjee.07@gmail.com (my email id).
